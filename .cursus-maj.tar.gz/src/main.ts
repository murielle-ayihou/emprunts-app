import { createApp } from 'vue'
import { createPinia } from 'pinia'
import App from './App.vue'
import { router } from './router'
import './assets/styles/main.css'

const app = createApp(App)
app.use(createPinia())
app.use(router)
app.config.errorHandler = (err) => {
  console.error('[Cursus]', err)
}
app.mount('#app')
